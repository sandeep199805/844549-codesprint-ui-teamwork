
function contactValidate(){

	var name = document.contactForm.name.value;
    localStorage.setItem("name",name.value);

    var email = document.contactForm.email.value;
    localStorage.setItem("email",email.value);

    var mobile = document.contactForm.mobile.value;
    localStorage.setItem("mobile",mobile.value);

    var country = document.contactForm.country.value;
    localStorage.setItem("country",country.value);

    var subject = document.contactForm.subject.value;
    localStorage.setItem("subject",subject.value);

    var nameErr = emailErr = mobileErr = countryErr = subjectErr = true;

    //validate name

    if(name == "") {
        printError("nameErr", "Please enter your name");
    } else {
        var regex = /^[a-zA-Z\s]+$/;                
        if(regex.test(name) === false) {
            printError("nameErr", "Please enter a valid name");
        } else {
            printError("nameErr", "");
            nameErr = false;
        }
    }


  //   //validate email
  //       var x=document.myform.email.value;  
  //      var atposition=x.indexOf("@");  
  //       var dotposition=x.lastIndexOf(".");  
  //         if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length){  
  //              alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
  //             emailErr = false;
  // }  
}  

    if(email == "") {
        printError("emailErr", "Please enter your email address");
    } else {
        // Regular expression for basic email validation
        var regex = /^\S+@\S+\.\S+$/;
        if(regex.test(email) === false) {
            printError("emailErr", "Please enter a valid email address");
        } else{
            printError("emailErr", "");
            emailErr = false;
        }
    }
    
    // Validate mobile number
    if(mobile == "") {
        printError("mobileErr", "Please enter your mobile number");
    } else {
        var regex = /^[1-9]\d{9}$/;
        if(regex.test(mobile) === false) {
            printError("mobileErr", "Please enter a valid 10 digit mobile number");
        } else{
            printError("mobileErr", "");
            mobileErr = false;
        }
    }
    
    // Validate country
 //    if(country == "Select") {
 //        printError("countryErr", "Please select your country");
 //    } else {
 //        printError("countryErr", "");
 //        countryErr = false;
 //    }
    
 //    // Validate gender
 //    if(subject == "") {
 //        printError("subjectErr", "Please enter Some text");

 // }

 function validateForm(){

    var fname = document.appointForm.firstname.value;
    var lname = document.appointForm.lastname.value;
    var age = document.appointForm.age.value;
    var email = document.appointForm.email.value;
    var phone = document.appointForm.phone.value;
    var address = document.appointForm.address.value;
    var city = document.appointForm.city.value;
    var state = document.appointForm.state.value;
    var pincode = document.appointForm.pincode.value;

 }
